import CompetitiveContentAnalyzer from "@/components/competitive-content-analyzer/competitive-content-analyzer";

const Home = () => {
  return <CompetitiveContentAnalyzer />;
};

export default Home;
